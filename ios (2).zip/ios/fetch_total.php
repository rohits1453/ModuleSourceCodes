<?php
require("dbconn.php");

// Initialize response array
$response = array();

// Assuming you have variables for scoredValue, totalScore, and outcome
$scoredValue = $_POST['scoredValue'];
$totalScore = $_POST['totalScore'];
$outcome = $_POST['outcome'];

// Query to insert values into checkboxes_values table
$sql = "INSERT INTO `checkboxes_values` (`patient_score`, `total_score`, `outcome`, `patient_id`) 
        VALUES ('$scoredValue', '$totalScore', '$outcome', 'your_patient_id_here')";

if ($conn->query($sql) === TRUE) {
    // Set the response status to true
    $response['status'] = true;
    $response['message'] = "New record created successfully";
    echo json_encode($response);
} else {
    // Set the response status to false
    $response['status'] = false;
    $response['message'] = "Error: " . $sql . "<br>" . $conn->error;
    echo json_encode($response);
}

$conn->close();
?>
