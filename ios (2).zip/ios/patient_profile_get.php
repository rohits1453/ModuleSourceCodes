<?php
// Include the database connection file
include_once "dbconn.php";

// Initialize response array
$response = array();

// Perform the query to get patient details
$query = "SELECT `patient_name`, `patient_mobile_number`, `patient_email`, `patient_password`, `patient_reenter_password` FROM `patient_table` WHERE 1";
$result = mysqli_query($conn, $query);

// Check if the query was successful
if ($result) {
    $patients = array();
    // Fetch each row from the result set
    while ($row = mysqli_fetch_assoc($result)) {
        // Add the patient details to the patients array
        $patients[] = $row;
    }
    // Close the result set
    mysqli_free_result($result);

    // Close the database connection
    mysqli_close($conn);

    // Set the response status to true
    $response['status'] = true;
    // Set the patient data array in the response
    $response['data'] = $patients;

    // Return the response in JSON format
    echo json_encode($response);
} else {
    // Set the response status to false
    $response['status'] = false;
    // Set the error message in the response
    $response['message'] = "Error retrieving patients: " . mysqli_error($conn);

    // Return the response in JSON format
    echo json_encode($response);
}
?>
