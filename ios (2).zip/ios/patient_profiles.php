<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Include the database connection file
    include_once "dbconn.php";

    // Get the form data
    $patient_name = $_POST["patient_name"];
    $patient_mobile_number = $_POST["patient_mobile_number"];
    $patient_email = $_POST["patient_email"];
    $patient_password = $_POST["patient_password"];
    $patient_reenter_password = $_POST["patient_reenter_password"];

    // Check if patient with the same email already exists
    $check_query = "SELECT * FROM patient_table WHERE patient_email = '$patient_email'";
    $result = mysqli_query($conn, $check_query);
    if (mysqli_num_rows($result) > 0) {
        // Update the data
        $update_query = "UPDATE patient_table SET patient_mobile_number='$patient_mobile_number', patient_email='$patient_email', patient_password='$patient_password', patient_reenter_password='$patient_reenter_password' WHERE patient_name='$patient_name'";
        if (mysqli_query($conn, $update_query)) {
            echo json_encode(array("status" => true, "message" => "Record updated successfully."));
        } else {
            echo json_encode(array("status" => false, "message" => "Error updating record: " . mysqli_error($conn)));
        }
    } else {
        echo json_encode(array("status" => false, "message" => "Patient with the same email does not exist."));
    }

    // Close the database connection
    mysqli_close($conn);
}
?>
