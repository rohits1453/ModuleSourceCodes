<?php
require_once 'dbconn.php';

// Initialize response array
$response = array();

// Check if the request method is GET
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    // Check if the patient_id parameter is provided
    if (isset($_GET['patient_id'])) {
        $patient_id = $_GET['patient_id'];

        // Perform the database query
        $sql = "SELECT patient_name, patient_age, patient_email, patient_mobile_number, patient_id FROM patient_table WHERE patient_id='$patient_id'";
        $result = $conn->query($sql);

        // Check if any rows were returned
        if ($result->num_rows > 0) {
            // Fetch the data and store it in an array
            $patientData = array();
            while ($row = $result->fetch_assoc()) {
                $patientData[] = $row;
            }

            // Set the response status to true
            $response['status'] = true;
            // Set the patient data array in the response
            $response['data'] = $patientData;

            // Return the data in JSON format
            echo json_encode($response);
        } else {
            // Set the response status to false
            $response['status'] = false;
            $response['message'] = "No data found for patient ID: $patient_id";

            // Return the response in JSON format
            echo json_encode($response);
        }
    } else {
        // Set the response status to false
        $response['status'] = false;
        $response['message'] = "Patient ID parameter is missing";

        // Return the response in JSON format
        echo json_encode($response);
    }
} else {
    // Invalid request method
    // Set the response status to false
    $response['status'] = false;
    $response['message'] = "Invalid request method";

    // Return the response in JSON format
    echo json_encode($response);
}

// Close the connection
$conn->close();
?>
