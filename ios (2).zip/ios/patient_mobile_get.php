<?php
require_once 'dbconn.php';

// Check if the request method is GET
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    // Check if the patient_mobile_number parameter is provided
    if (isset($_GET['patient_mobile_number'])) {
        $patient_mobile_number = $_GET['patient_mobile_number'];

        // Perform the database query
        $sql = "SELECT patient_name, patient_email, patient_mobile_number, patient_password, patient_reenter_password FROM patient_table WHERE patient_mobile_number='$patient_mobile_number'";
        $result = $conn->query($sql);

        // Check if any rows were returned
        if ($result->num_rows > 0) {
            // Fetch the data and store it in an array
            $patientData = array();
            while ($row = $result->fetch_assoc()) {
                $patientData[] = $row;
            }

            // Return the data with status true
            $response = array(
                "status" => true,
                "message" => "Data found for mobile number: $patient_mobile_number",
                "data" => $patientData
            );
            echo json_encode($response);
        } else {
            // No data found for the mobile number
            $response = array(
                "status" => false,
                "message" => "No data found for mobile number: $patient_mobile_number",
                "data" => ""
            );
            echo json_encode($response);
        }
    } else {
        // Mobile number parameter is missing
        $response = array(
            "status" => false,
            "message" => "Mobile number parameter is missing",
            "data" => ""
        );
        echo json_encode($response);
    }
} else {
    // Invalid request method
    $response = array(
        "status" => false,
        "message" => "Invalid request method",
        "data" => ""
    );
    echo json_encode($response);
}

// Close the connection
$conn->close();
?>
