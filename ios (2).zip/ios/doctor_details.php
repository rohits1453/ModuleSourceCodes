<?php
require 'dbconn.php';

// Initialize response array
$response = array();

// SQL query to fetch doctor details
$sql = "SELECT `s_no`, `doctor_id`, `password`, `doctor_name`, `doctor_email`, `doctor_specification`, `doctor_mobilenumber`, `doctor_qualification`, `doctor_experience`, `doctor_education`, `doctor_location` FROM `doctor_table` WHERE 1";
$result = $conn->query($sql);

$doctorDetailsArray = array(); // Array to hold doctor details

if ($result->num_rows > 0) {
    // Output data of each row
    while($row = $result->fetch_assoc()) {
        $doctorId = $row["doctor_id"];
        $doctorName = $row["doctor_name"];
        $doctorSpecification = $row["doctor_specification"];
        $doctorExperience = $row["doctor_experience"];
        $doctorEducation = $row["doctor_education"];
        $doctorQualification = $row["doctor_qualification"];
        $doctorLocation = $row["doctor_location"];
        
        // Create an array to hold the data
        $doctorDetails = array(
            "doctor_id" => $doctorId,
            "doctor_name" => $doctorName,
            "doctor_specification" => $doctorSpecification,
            "doctor_experience" => $doctorExperience,
            "doctor_education" => $doctorEducation,
            "doctor_qualification" => $doctorQualification,
            "doctor_location" => $doctorLocation
        );

        // Push the doctor details array into the main array
        array_push($doctorDetailsArray, $doctorDetails);
    }

    // Set the response status to true
    $response['status'] = true;
    // Set the doctor details array in the response
    $response['doctor_details'] = $doctorDetailsArray;
} else {
    // Set the response status to false
    $response['status'] = false;
    $response['message'] = "0 results";
}

// Encode the response as JSON and output it
echo json_encode($response);

// Close the connection
$conn->close();
?>
