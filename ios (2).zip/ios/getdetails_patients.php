<?php
require('dbconn.php');

// Initialize response array
$response = array();

$sql = "SELECT `patient_id`, `patient_name`, `patient_age`, `patient_gender` FROM `patient_table` WHERE 1";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Array to hold patient data
    $patients = array();

    // Fetch data from each row and add to the patients array
    while($row = $result->fetch_assoc()) {
        $patient = array(
            'patient_id' => $row["patient_id"],
            'patient_name' => $row["patient_name"],
            'patient_age' => $row["patient_age"],
            'patient_gender' => $row["patient_gender"]
        );
        $patients[] = $patient;
    }

    // Set the response status to true
    $response['status'] = true;
    // Set the patient details array in the response
    $response['data'] = $patients;
    
    // Send JSON response
    header('Content-Type: application/json');
    echo json_encode($response);
} else {
    // Set the response status to false
    $response['status'] = false;
    $response['message'] = "0 results";
    
    // Send JSON response
    header('Content-Type: application/json');
    echo json_encode($response);
}
$conn->close();
?>
