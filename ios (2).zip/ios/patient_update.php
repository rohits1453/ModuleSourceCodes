<?php
require 'dbconn.php';

// Initialize response array
$response = array();

// Check if the doctor ID is set in the POST request
if(isset($_POST['doctor_id'])) {
    $doctorId = $_POST['doctor_id'];

    // SQL query to fetch doctor details based on the doctor ID
    $sql = "SELECT `s_no`, `doctor_id`, `password`, `doctor_name`, `doctor_email`, `doctor_specification`, `doctor_mobilenumber`, `doctor_qualification`, `doctor_experience`, `doctor_education`, `doctor_location` FROM `doctor_table` WHERE `doctor_id` = '$doctorId'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Output data of the selected row
        $row = $result->fetch_assoc();
        $doctorId = $row["doctor_id"];
        $doctorName = $row["doctor_name"];
        $doctorEmail = $row["doctor_email"];
        $doctorSpecification = $row["doctor_specification"];
        $doctormobilenumber = $row["doctor_mobilenumber"];
        $doctorExperience = $row["doctor_experience"];
        $doctorEducation = $row["doctor_education"];
        $doctorQualification = $row["doctor_qualification"];
        $doctorLocation = $row["doctor_location"];
        $doctorpassword = $row["password"];
        
        // Create an array to hold the data
        $doctorDetails = array(
            "doctor_id" => $doctorId,
            "doctor_name" => $doctorName,
            "doctor_email" => $doctorEmail,
            "doctor_specification" => $doctorSpecification,
            "doctor_mobilenumber" => $doctormobilenumber,
            "doctor_experience" => $doctorExperience,
            "doctor_education" => $doctorEducation,
            "doctor_qualification" => $doctorQualification,
            "doctor_location" => $doctorLocation,
            "password"  => $doctorpassword
        );

        // Set the response status to true
        $response['status'] = true;
        // Set the doctor details array in the response
        $response['doctor_details'] = $doctorDetails;
    } else {
        // Set the response status to false
        $response['status'] = false;
        $response['message'] = "Doctor not found";
    }
} else {
    // Set the response status to false
    $response['status'] = false;
    $response['message'] = "Doctor ID not provided";
}

// Encode the response as JSON and output it
echo json_encode($response);

// Close the connection
$conn->close();
?>
