package com.example.drscareapp;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import java.util.HashMap;
import java.util.Map;

public class java_doctor_login extends AppCompatActivity {

    private static final String URL_INSERT_DOCTOR = IPv4Connection.getBaseUrl()+"doctor_login.php"; // Change this to your actual server address

    EditText editTextDoctorId;
    EditText editTextPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.page3);

        editTextDoctorId = findViewById(R.id.editTextNumberSigned);
        editTextPassword = findViewById(R.id.editTextTextPassword);

        TextView textView6 = findViewById(R.id.textView6);
        TextView textView8 = findViewById(R.id.textView8);

        Button button = findViewById(R.id.button);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String enteredDoctorId = editTextDoctorId.getText().toString();
                String enteredPassword = editTextPassword.getText().toString();

                insertDoctorData(enteredDoctorId, enteredPassword);
            }
        });

        textView6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(java_doctor_login.this, "Contact Administrator!!", Toast.LENGTH_SHORT).show();
            }
        });

        textView8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(java_doctor_login.this, "Contact Administrator!!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void insertDoctorData(final String doctorId, final String password) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL_INSERT_DOCTOR,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        if (response.trim().equals("success")) {
                            Toast.makeText(java_doctor_login.this, "Login Successful", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(java_doctor_login.this, java_doctor_homepage.class);
                            startActivity(intent);
                        } else {
                            Toast.makeText(java_doctor_login.this, "Incorrect Id or Password", Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(java_doctor_login.this, "Error: " + error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("doctor_id", doctorId);
                params.put("password", password);
                return params;
            }
        };

        Volley.newRequestQueue(this).add(stringRequest);
    }
}
