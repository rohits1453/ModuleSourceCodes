package com.example.drscareapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class java_your_appointments extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.patientdata);

    }
}