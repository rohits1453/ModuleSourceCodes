package com.example.drscareapp;

import android.app.Activity;

public class side_menu_items extends Activity {
}
