package com.example.drscareapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class content_patientprofile extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_content_patientprofile);

    }
}