package com.example.drscareapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class content_patient_homepage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_list_of_doctors);

    }
}