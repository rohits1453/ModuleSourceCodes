package com.example.drscareapp;

//import com.google.gson.Gson;
//import com.google.gson.GsonBuilder;
//
//import java.util.List;
//
//import retrofit2.Call;
//import retrofit2.Retrofit;
//import retrofit2.http.GET;
//
//public interface ApiService {
//    @GET("getdetails_patients.php")
//    Call<List<Item>> getItems();
//
//
//    Gson gson = new GsonBuilder()
//            .setLenient()
//            .create();
//
//    Retrofit retrofit = new Retrofit.Builder()
//            .baseUrl("http://10.0.2.2/")
//            .addConverterFactory(GsonConverterFactory.create(gson))
//            .build();
//
//    ApiService apiService = retrofit.create(ApiService.class);
//}


